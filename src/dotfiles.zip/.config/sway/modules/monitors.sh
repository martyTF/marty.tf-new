#!/bin/bash
#
# CONFIGURE THIS YOURSELF, AS I DO NOT KNOW YOUR MONITOR SETUP https://man.archlinux.org/man/sway.5.en#COMMANDS
#
### Output configuration
#
# Default wallpaper (more resolutions are available in /usr/share/backgrounds/sway/)
# Requires: desktop-backgrounds-compat, swaybg
output * bg #28211c solid_color
#
# Example configuration:
#
output HDMI-A-1 resolution 1920x1080 position 0,0
output DP-1 resolution 2560x1440@143.912Hz position 1920,0
output DP-3 disable
#
# You can get the names of your outputs by running: swaymsg -t get_outputs


# Enable XWayland
 xwayland enable