#!/bin/bash
#
# Notifier server
#
# Execute program; configuration included

exec mako --max-history 10 --font "Comic Mono 13" --background-color "#28211c" --text-color "#cfcdc9" --width 400 --height 200 --outer-margin 30 --border-size 3 --border-color "#cc694b" --border-radius 5 --icon 1 --max-visible 5 --output HDMI-A-1 --anchor top-right --default-timeout 20000 --progress-color "source #28211c" --progress-color "over #cc694b"

