#!/bin/bash

# Gaps. The most important part
gaps inner 20
gaps outer 10
# Titlebar and Border shenanigans
default_border pixel 3
default_floating_border pixel
client.background n/a #333333 n/a
client.focused #cfcdc9 #cfcdc9 #cfcdc9 #cfcdc9 #cfcdc9
client.focused_inactive #e68466 #e68466 #e68466 #e68466
client.unfocused #e68466 #e68466 #e68466 #e68466 #e68466
client.urgent #cc694b #cc694b #cc694b #cc694b #cc694b
smart_gaps off
smart_borders off

#workspace bananza
workspace 0 output HDMI-A-1
workspace 1 output HDMI-A-1
workspace 2 output DP-1
workspace 3 output DP-1
workspace 4 output DP-1
workspace 5 output DP-1
workspace 6 output DP-1
workspace 7 output DP-1
workspace 8 output DP-1
workspace 9 output DP-1
# Gaps. The most important part
gaps inner 20
gaps outer 10
# Titlebar and Border shenanigans
default_border pixel 3
default_floating_border pixel
client.background n/a #333333 n/a
client.focused #cfcdc9 #cfcdc9 #cfcdc9 #cfcdc9 #cfcdc9
client.focused_inactive #e68466 #e68466 #e68466 #e68466
client.unfocused #e68466 #e68466 #e68466 #e68466 #e68466
client.urgent #cc694b #cc694b #cc694b #cc694b #cc694b
smart_gaps off
smart_borders off

#workspace bananza
workspace 0 output HDMI-A-1
workspace 1 output HDMI-A-1
workspace 2 output DP-1
workspace 3 output DP-1
workspace 4 output DP-1
workspace 5 output DP-1
workspace 6 output DP-1
workspace 7 output DP-1
workspace 8 output DP-1
workspace 9 output DP-1

# Focus stops following mouse
focus_follows_mouse no



exec flameshot

exec swaymsg "workspace 1; exec /usr/lib64/discord/Discord;"
assign [class="discord"] workspace 1
exec swaymsg "workspace 1; exec firefox;"

exec swaymsg "workspace 2; exec steam;"
exec swaymsg "workspace 2; exec heroic;"
assign [class="Steam"] workspace 2
assign [class="heroic"] workspace 2

assign [class="steam_app_*"] workspace 3
assign [app_id="yad"] workspace 3
assign [app_id="org.prismlauncher.PrismLauncher"] workspace 3
assign [class="Minecraft"] workspace 3

exec swaymsg "workspace 5; exec flatpak run com.vscodium.codium;"


exec swaymsg "workspace 4; exec kitty;"

assign [class="steam_proton"] workspace 7

exec swaymsg "workspace 9; exec sonixd;"

# fix flameshot
for_window [app_id="flameshot"] floating enable, fullscreen disable, move absolute position 0 0, border pixel 0
exec flatpak run org.flameshot.Flameshot


mouse_warping none



for_window [window_role="pop-up"] floating enable
for_window [window_role="bubble"] floating enable
for_window [window_role="dialog"] floating enable
for_window [window_type="dialog"] floating enable
for_window [window_role="task_dialog"] floating enable
for_window [window_type="menu"] floating enable
for_window [app_id="floating"] floating enable
for_window [app_id="floating_update"] floating enable, resize set width 1000px height 600px
for_window [app_id="Yad"] floating enable
for_window [app_id="yad"] floating enable

# https://github.com/ValveSoftware/steam-for-linux/issues/1040
for_window [class="^Steam$" title="^Friends$"] floating enable
for_window [class="^Steam$" title="Steam - News"] floating enable
for_window [class="^Steam$" title=".* - Chat"] floating enable
for_window [class="^Steam$" title="^Settings$"] floating enable
for_window [class="^Steam$" title=".* - event started"] floating enable
for_window [class="^Steam$" title=".* CD key"] floating enable
for_window [class="^Steam$" title="^Steam - Self Updater$"] floating enable
for_window [class="^Steam$" title="^Screenshot Uploader$"] floating enable
for_window [class="^Steam$" title="^Steam Guard - Computer Authorization Required$"] floating enable
for_window [title="^Steam Keyboard$"] floating enable
