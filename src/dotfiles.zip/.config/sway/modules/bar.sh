#!/bin/bash

# Waybar: Just the launch, configuration is at $HOME/.config/waybar/config

bar {
    position top
    swaybar_command waybar
}