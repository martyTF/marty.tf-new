#!/bin/bash

ACTIVEWORKSPACE=$(swaymsg -t get_workspaces --pretty | grep "(focused)" | sed 's/Workspace //' | sed 's/ (focused)//')

if [ $ACTIVEWORKSPACE = 9 ]; then
  NEWWORKSPACE="number 2"
elif [ $ACTIVEWORKSPACE = 1 ]; then 
  NEWWORKSPACE="number 0"
else
  NEWWORKSPACE="number $(($ACTIVEWORKSPACE+1))"
fi


sway workspace $NEWWORKSPACE || kitty --hold -e echo error
