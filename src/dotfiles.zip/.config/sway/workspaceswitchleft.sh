#!/bin/bash

ACTIVEWORKSPACE=$(swaymsg -t get_workspaces --pretty | grep "(focused)" | sed 's/Workspace //' | sed 's/ (focused)//')

if [ $ACTIVEWORKSPACE = 2 ]; then
  NEWWORKSPACE="number 9"
elif [ $ACTIVEWORKSPACE = 0 ]; then 
  NEWWORKSPACE="number 1"
else
  NEWWORKSPACE="number $(($ACTIVEWORKSPACE-1))"
fi


sway workspace $NEWWORKSPACE || kitty --hold -e echo error


# todo: cat this into one file by adding a $1 selector: $1 > $WORKSPACEDIRECTION > left/right
